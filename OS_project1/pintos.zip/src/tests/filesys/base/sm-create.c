/* Tests that create properly zeros out the contents of a fairly
   small file. */

#define TEST_SIZE 5678
#include "tests/filesys/create.inc"
